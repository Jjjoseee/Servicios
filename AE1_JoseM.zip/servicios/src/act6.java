import java.util.ArrayList;
import java.util.Scanner;

public class act6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sn = new Scanner(System.in);
		ArrayList<Integer> n = new ArrayList<Integer>();

		for (int g = 0; g <=4; g++) {

			System.out.println("Numero: "+(g+1)+": ");
			n.add(Integer.parseInt(sn.nextLine()));
			
		}
		System.out.println("\n");
		int sum = 0;
		for ( int h = 4;h >= 0 ; h-- ) {
			System.out.println(n.get(h));
			sum += n.get(h);
		}
		System.out.println("\nSuma total: "+sum);
	}

}
