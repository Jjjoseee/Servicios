
public class act3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int total = 0;
		int n = Integer.parseInt(args[0]);
		for ( int w = 0; w <= n; w++) {
			if (w % 2==0) {
				total += w;
			}
		}
		System.out.println("Suma hasta "+n+": "+total);
	}

}
