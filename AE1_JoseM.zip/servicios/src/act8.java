import java.util.Scanner;

public class act8 {

	public static void main(String[] args) {

		Scanner sn = new Scanner(System.in);

		System.out.println("Num 1: ");
		int n1 = Integer.parseInt(sn.nextLine());

		System.out.println("Num 2: ");
		int n2 = Integer.parseInt(sn.nextLine());

		int sum = n1;

		for (int w = n1; w < (n2 - 1); w++) {
			sum += 1;

			if (comprobarPrimo(sum)) {

				System.out.println(sum + " - Es primo");
			} else {
				System.out.println(sum + " - No es primo");
			}
		}
	}

	public static boolean comprobarPrimo(int numero) {

		if (numero == 0 || numero == 1 || numero == 4) {
			return false;
		}
		for (int x = 2; x < numero / 2; x++) {

			if (numero % x == 0)
				return false;
		}

		return true;
	}

}
