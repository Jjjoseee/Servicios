import java.util.Scanner;

public class act7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sn = new Scanner(System.in);
		
		System.out.println("Nom: ");
		String nom = sn.nextLine();
		
		System.out.println("Anys: ");
		int any = Integer.parseInt(sn.nextLine());
		
		System.out.println("\n");
		if (any < 1) {
			System.out.println(nom+" es "+"Desarrollador Junior L1 � 15000-18000");
		}else if(any >1 && any < 3) {
			System.out.println(nom+" es "+"Desarrollador Junior L2 � 18000-22000");

		}else if(any >2 && any < 5) {
			System.out.println(nom+" es "+"Desarrollador Senior L1 � 22000-28000");

		}else if(any >4 && any < 9) {
			System.out.println(nom+" es "+"Desarrollador Senior L2 � 28000-36000");

		}else {
			System.out.println(nom+" es "+"Analista / Arquitecto. Salario a convenir en base a rol");

		}
	}

}
