
public class act4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long factorial=1;
        int n = 15;
       for (int i = n; i > 0; i--) {
            factorial = factorial * i;
        }
        System.out.println("El factorial de " + n + " es: " + factorial);
	}

}
