import java.util.ArrayList;

public class act2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] lista = {"Jose","Adrian","Carlos","Pablo","Victor","Alvaro"};
		System.out.println("Parte 1\n");

		for (int i = 0; i < lista.length; i++) {
			System.out.println(lista[i]);
		}
		System.out.println("_____________________\n");
		System.out.println("Parte 2\n");


		ArrayList<String> noms = new ArrayList<String>();
		noms.add("Hector");
		noms.add("Adrian");
		noms.add("Carlos");
		noms.add("Pablo");
		noms.add("Victor");
		noms.add("Alvaro");
	
	for (int i = 0; i < noms.size(); i++) {
		System.out.println(noms.get(i));
	}

}
}
