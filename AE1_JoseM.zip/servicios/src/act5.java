
public class act5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] lista = {3,5,7,55,9,34,6};
		int mayor = 0;
		for (int i = 0; i < lista.length; i++) {
			if (lista[i]>mayor) {
				mayor = lista[i];
			}
		}
		System.out.println("El mayor es: "+mayor);
	}

}
