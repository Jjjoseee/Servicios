package av2;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

public class princ {

	public static double calcularColisionNEO(double posicionNEO, double velocidadNEO) {

		double posicionTierra = 1;
		double velocidadTierra = 100;
		for (int i = 0; i < (50 * 365 * 24 * 60 * 60); i++) {
			posicionNEO = posicionNEO + velocidadNEO * i;
			posicionTierra = posicionTierra + velocidadTierra * i;
		}
		double resultado = 100 * Math.random()
				* Math.pow(((posicionNEO - posicionTierra) / (posicionNEO + posicionTierra)), 2);
		BigDecimal bd = new BigDecimal(resultado).setScale(2, RoundingMode.HALF_UP);
		double result2 = bd.doubleValue();
		return result2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BufferedReader bufferedReader = null;
		String nombre = "";
		Double pos = 0.00;
		Double vel = 0.00;

		try {
			bufferedReader = new BufferedReader(new FileReader("NEOs.txt"));
			String row = "";

			while ((row = bufferedReader.readLine()) != null) {

				StringBuilder stringBuilder = new StringBuilder();
				String[] data = row.split(",");
				nombre = data[0];
				pos = Double.parseDouble(data[1]);
				vel = Double.parseDouble(data[2]);
				if (calcularColisionNEO(pos, vel) >= 10.00) {
					System.out.println(nombre + "  ---  Probabilidad: " + calcularColisionNEO(pos, vel)
					+ " -> ���ALERTA MUNDIAL!!!");
				} else {
					System.out.println(nombre + "  ---  Probabilidad: " + calcularColisionNEO(pos, vel));
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		if (bufferedReader != null) {
			try {
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		System.out.println("\n_________________end_________________");

		// System.out.println(calcularColisionNEO());

	}

}
