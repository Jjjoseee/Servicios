package av2;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.time.Duration;
import java.time.Instant;
import java.time.Duration;
import java.time.Instant;


public class Sumador {
	//funcion para calcular la probabilidad de colisoin, le entran en nombre, posicion y velocidad de los asteroides
	public static void calcularColisionNEO(String nombre, double posicionNEO, double velocidadNEO) {
		long startTime = System.nanoTime();
		double posicionTierra = 1;
		double velocidadTierra = 100;
		for (int i = 0; i < (50 * 365 * 24 * 60 * 60); i++) {
			posicionNEO = posicionNEO + velocidadNEO * i;
			posicionTierra = posicionTierra + velocidadTierra * i;
		}
		double resultado = 100 * Math.random()
				* Math.pow(((posicionNEO - posicionTierra) / (posicionNEO + posicionTierra)), 2);
		BigDecimal bd = new BigDecimal(resultado).setScale(2, RoundingMode.HALF_UP);
		double result2 = bd.doubleValue();
		if (result2 >= 10.00) {
			System.err.println(
					nombre + "  ---  Probabilidad: " + result2 + "% -> ���ALERTA MUNDIAL!!!\n");
		} else {
			System.out.println(nombre + "  ---  Probabilidad: " + result2+"%\n");
		}
		
	}
	
	
	
	//main que ejecuta la fuccion calcularColisionNEO cogiendo las variables de argumentos
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nombre = args[0];
		double pos = Double.parseDouble(args[1]);
		double vel = Double.parseDouble(args[2]);

		calcularColisionNEO(nombre, pos, vel);
		// System.out.println(calcularColisionNEO());

	}

}
