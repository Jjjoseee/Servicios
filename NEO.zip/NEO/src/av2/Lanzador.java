package av2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Lanzador {
	
	static int cores = Runtime.getRuntime().availableProcessors();
	static int maxcores = 1;
	
	public void lanzarSumador(String nombre, Double pos, Double vel) {
		String clase = "av2.Sumador";
		try {

			String javaHome = System.getProperty("java.home");
			String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
			String classpath = System.getProperty("java.class.path");
			// System.out.println(classpath);
			String className = clase;

			List<String> command = new ArrayList<>();
			command.add(javaBin);
			command.add("-cp");
			command.add(classpath);
			command.add(className);
			
			//envia las variables leidas en el txt a las posicions de argumentos 0, 1, 2
			command.add(nombre.toString());
			command.add(pos.toString());
			command.add(vel.toString());

			// System.out.println("Comando que se pasa a ProcessBuilder: " + command);
			// System.out.println("Comando a ejecutar en cmd.exe: " + command.toString().replace(",",""));

			ProcessBuilder builder = new ProcessBuilder(command);
			Process process = builder.inheritIO().start();
			// Process process = builder.start();
			
			//ejecuta el sumador tantas veces como cores disponibles
			if(cores == maxcores) {
				process.waitFor();
			}else {
				maxcores++;
			}
			
			//errores
			//System.out.println(process.exitValue());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//lee el archivo txt, y separa y saca las variables de nombre posiv�cion y velocidad, tambien contamos el tiempo de ejecucion
	public static void main(String[] args) {

		BufferedReader bufferedReader = null;
		String nombre = "";
		Double pos = 0.00;
		Double vel = 0.00;
		long startTime = System.nanoTime();
		int max=0;
		
		//lector del txt
		try {
			bufferedReader = new BufferedReader(new FileReader("NEOs.txt"));
			String row = "";

			while ((row = bufferedReader.readLine()) != null && cores>max) {
				String[] data = row.split(",");
				nombre = data[0];
				pos = Double.parseDouble(data[1]);
				vel = Double.parseDouble(data[2]);
				Lanzador l = new Lanzador();
				l.lanzarSumador(nombre, pos, vel);
								
				//Si comentamos, ejecutara todas las lineas del fichero--------------------------------------
				max++;								
				
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		if (bufferedReader != null) {
			try {
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		long endTime = System.nanoTime();
		long duration = (endTime - startTime);
		try {
			Thread.sleep(750);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//info de variables que gestionan los cores
		//System.out.println("Cores: "+cores+"    Max: "+max + "    Maxcores: "+maxcores);
		System.out.println("\n\nTiempo de ejecion: "+(duration/1000000000)+" segundos.\n____________________________________________________");
	}

}
