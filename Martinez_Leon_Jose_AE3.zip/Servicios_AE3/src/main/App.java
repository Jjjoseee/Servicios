package main;

import java.util.ArrayList;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		//crea una mina y un arraylist de mineros
		Mina m = new Mina(11000);
		ArrayList<Minero> s = new ArrayList<Minero>();
		Thread t;
		
		//por cada hilo, se crea un minero, en este caso 15
		for (int i = 0; i < 15; i++) {
			Minero f = new Minero(m);
			s.add(f);
			t = new Thread(f);
			t.setName("Minero " + (i + 1));
			t.start();
		}
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // Pausa para dejar que acaben todos los threads
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//se suma todo el oro extraido por todos los mineros y se muestra por consola
		int totaloro = 0;
		for (Minero minero : s) {	
			 totaloro += minero.bolsa;
		} System.out.println("Total oro extraido: " + totaloro);
	}

	




}
