package main;

import java.sql.Time;

//creacion de los mineros, todos con la misma mina
public class Minero implements Runnable {

	int bolsa;
	int tiempoExtraccion = 1000;
	Mina mina;

	public Minero(Mina m) {
		this.bolsa = 0;
		this.mina = m;
	}
	//clase estraerRecurso, extrae una cantidad de oro ya deifinda fuera,
	//e informa de el oro extraido y bolsa actual de cada minero
	//recibe nombre de minero y oro a extraer por turno
	synchronized public void extraerRecurso(String nombre,int oro) {
		// public void reservaEntrada (String nombre, int entradas) {
		while (mina.stock > 0) {
			try {
				Thread.sleep(tiempoExtraccion);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		if (mina.getStock()>0) {
			this.bolsa = this.bolsa + oro;
			System.out.println(nombre +" ha extraido "+oro + " de oro"+"  |  "+ "Bolsa del minero "+nombre+": " + this.bolsa);
			mina.setStock(mina.getStock()-oro);
		} 
	}System.out.println("No queda oro");
	}
	
	//clase donde se ejecutan los extraer recursos, se le puede pasar una cantidad random,
	//o una predefinida, en este caso esta puesta -100-
	
	@Override
	public void run () {
		String nombre = Thread.currentThread().getName ();
		int oro = (int) (Math.random() * 10 + 1);
		extraerRecurso(nombre, 100);
		}
	
	
	
	
	

	// geters
	public int getBolsa() {
		return this.bolsa;
	}

	public int gettiempoExtraccion() {
		return this.tiempoExtraccion;
	}

	// seters
	public void setBolsa(int i) {
		this.bolsa = i;
	}

	public void settiempoExtraccion(int i) {
		this.tiempoExtraccion = i;
	}



}