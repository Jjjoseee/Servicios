package main;

public class Mina {

	int stock;
	

	public Mina(int stk) {
		this.stock = stk;
		
	}
	
	//geters
	public int getStock() {
		return this.stock;
	}

	
	//seters
	public void setStock(int i) {
		this.stock = i;
	}

}